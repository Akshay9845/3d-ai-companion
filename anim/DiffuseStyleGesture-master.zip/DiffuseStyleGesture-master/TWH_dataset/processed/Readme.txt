You will get the processed TWH dataset here


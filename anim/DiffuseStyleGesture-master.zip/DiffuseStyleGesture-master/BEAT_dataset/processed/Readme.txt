You will get the processed BEAT dataset here


import pdb
import torch
import torch.nn as nn
from torch.nn import functional as F
import math
# from denoising_diffusion_pytorch import myUnet1D, myGaussianDiffusion1D


class WavEncoder(nn.Module):        # (b, 64000) -> (b, 240, 32)
    def __init__(self):
        super().__init__()
        self.feat_extractor = nn.Sequential(
            nn.Conv1d(1, 16, 15, stride=3, padding=800),
            nn.BatchNorm1d(16),
            nn.LeakyReLU(0.3, inplace=True),
            nn.Conv1d(16, 32, 15, stride=3),
            nn.BatchNorm1d(32),
            nn.LeakyReLU(0.3, inplace=True),
            nn.Conv1d(32, 64, 15, stride=5),
            nn.BatchNorm1d(64),
            nn.LeakyReLU(0.3, inplace=True),
            nn.Conv1d(64, 32, 15, stride=6),
        )

    def forward(self, wav_data):
        wav_data = wav_data.unsqueeze(1)  # add channel dim
        out = self.feat_extractor(wav_data)
        return out.transpose(1, 2)  # to (batch x seq x dim)


class Generator_linear(nn.Module):
    def __init__(self):
        super().__init__()
        self.WavEncoder = WavEncoder()
        self.project = nn.Linear(32, 512, bias=False)
        self.norm = nn.LayerNorm(32)

    def sample(self, x):
        wav_feature = self.WavEncoder(x)
        wav_feature = self.norm(wav_feature)          # (1, 30, 512)
        codebook_embedding = self.project(wav_feature).squeeze()
        # codebook_embedding = self.norm(codebook_embedding).squeeze()      # (1, 30, 512)
        code = torch.tensor([]).to(x.device)
        for k in codebook_embedding:
            probs = F.softmax(k, dim=-1)
            _, ix = torch.topk(probs, k=1, dim=-1)
            code = torch.cat((code, ix))
        return [code.unsqueeze(0).int()]

    def forward(self, x, target=None):
        wav_feature = self.WavEncoder(x)
        wav_feature = self.norm(wav_feature)        # norm before linear
        codebook_embedding = self.project(wav_feature)
        loss = None
        if target is not None:
            loss = F.cross_entropy(codebook_embedding.view(-1, codebook_embedding.size(-1)), target.view(-1))
        return codebook_embedding, loss

'''
Based on the following Se2Seq implementations:
- https://github.com/AuCson/PyTorch-Batch-Attention-Seq2seq
- https://github.com/spro/practical-pytorch/blob/master/seq2seq-translation/seq2seq-translation-batched.ipynb
'''


class EncoderRNN(nn.Module):
    def __init__(self, input_size, embed_size, hidden_size, n_layers=1, dropout=0.5, pre_trained_embedding=None):
        super(EncoderRNN, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.embed_size = embed_size
        self.n_layers = n_layers
        self.dropout = dropout

        if pre_trained_embedding is not None:  # use pre-trained embedding (e.g., word2vec, glove)
            assert pre_trained_embedding.shape[0] == input_size
            assert pre_trained_embedding.shape[1] == embed_size
            self.embedding = nn.Embedding.from_pretrained(torch.FloatTensor(pre_trained_embedding), freeze=False)
        else:
            self.embedding = nn.Embedding(input_size, embed_size)

        self.gru = nn.GRU(embed_size, hidden_size, n_layers, dropout=self.dropout, bidirectional=True)

        self.do_flatten_parameters = False
        if torch.cuda.device_count() > 1:
            self.do_flatten_parameters = True

    def forward(self, input_seqs, input_lengths, hidden=None):
        '''
        :param input_seqs:
            Variable of shape (num_step(T),batch_size(B)), sorted decreasingly by lengths(for packing)
        :param input_lengths:
            list of sequence length
        :param hidden:
            initial state of GRU
        :returns:
            GRU outputs in shape (T,B,hidden_size(H))
            last hidden stat of RNN(i.e. last output for GRU)
        '''
        if self.do_flatten_parameters:
            self.gru.flatten_parameters()

        embedded = self.embedding(input_seqs)
        packed = torch.nn.utils.rnn.pack_padded_sequence(embedded, input_lengths)
        outputs, hidden = self.gru(packed, hidden)
        outputs, output_lengths = torch.nn.utils.rnn.pad_packed_sequence(outputs)  # unpack (back to padded)
        outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]  # Sum bidirectional outputs
        return outputs, hidden


class Attn(nn.Module):
    def __init__(self, hidden_size):
        super(Attn, self).__init__()
        self.hidden_size = hidden_size
        self.attn = nn.Linear(self.hidden_size * 2, hidden_size)
        self.v = nn.Parameter(torch.rand(hidden_size))
        stdv = 1. / math.sqrt(self.v.size(0))
        self.v.data.normal_(mean=0, std=stdv)

    def forward(self, hidden, encoder_outputs):
        '''
        :param hidden:
            previous hidden state of the decoder, in shape (layers*directions,B,H)
        :param encoder_outputs:
            encoder outputs from Encoder, in shape (T,B,H)
        :return
            attention energies in shape (B,T)
        '''
        max_len = encoder_outputs.size(0)
        this_batch_size = encoder_outputs.size(1)
        H = hidden.repeat(max_len, 1, 1).transpose(0, 1)
        encoder_outputs = encoder_outputs.transpose(0, 1)  # [B*T*H]
        attn_energies = self.score(H, encoder_outputs)  # compute attention score
        return F.softmax(attn_energies, dim=1).unsqueeze(1)  # normalize with softmax

    def score(self, hidden, encoder_outputs):
        energy = torch.tanh(self.attn(torch.cat([hidden, encoder_outputs], 2)))  # [B*T*2H]->[B*T*H]
        energy = energy.transpose(2, 1)  # [B*H*T]
        v = self.v.repeat(encoder_outputs.data.shape[0], 1).unsqueeze(1)  # [B*1*H]
        energy = torch.bmm(v, energy)  # [B*1*T]
        return energy.squeeze(1)  # [B*T]


class BahdanauAttnDecoderRNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, n_layers=1, dropout_p=0.1,
                 discrete_representation=False, speaker_model=None):
        super(BahdanauAttnDecoderRNN, self).__init__()

        # define parameters
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.n_layers = n_layers
        self.dropout_p = dropout_p
        self.discrete_representation = discrete_representation
        self.speaker_model = speaker_model

        # define embedding layer
        if self.discrete_representation:
            self.embedding = nn.Embedding(output_size, hidden_size)
            self.dropout = nn.Dropout(dropout_p)

        if self.speaker_model:
            self.speaker_embedding = nn.Embedding(speaker_model.n_words, 8)

        # calc input size
        if self.discrete_representation:
            input_size = hidden_size  # embedding size
        linear_input_size = input_size + hidden_size
        if self.speaker_model:
            linear_input_size += 8

        # define layers
        self.pre_linear = nn.Sequential(
            nn.Linear(linear_input_size, hidden_size),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(inplace=True)
        )
        self.attn = Attn(hidden_size)
        self.gru = nn.GRU(hidden_size, hidden_size, n_layers, dropout=dropout_p)

        # self.out = nn.Linear(hidden_size * 2, output_size)
        self.out = nn.Linear(hidden_size, output_size)

        self.do_flatten_parameters = False
        if torch.cuda.device_count() > 1:
            self.do_flatten_parameters = True

    def freeze_attn(self):
        for param in self.attn.parameters():
            param.requires_grad = False

    def forward(self, motion_input, last_hidden, encoder_outputs, vid_indices=None):
        '''
        :param motion_input:
            motion input for current time step, in shape [batch x dim]
        :param last_hidden:
            last hidden state of the decoder, in shape [layers x batch x hidden_size]
        :param encoder_outputs:
            encoder outputs in shape [steps x batch x hidden_size]
        :param vid_indices:
        :return
            decoder output
        Note: we run this one step at a time i.e. you should use a outer loop
            to process the whole sequence
        '''

        if self.do_flatten_parameters:
            self.gru.flatten_parameters()

        if self.discrete_representation:
            word_embedded = self.embedding(motion_input).view(1, motion_input.size(0), -1)  # [1 x B x embedding_dim]
            motion_input = self.dropout(word_embedded)
        else:
            motion_input = motion_input.view(1, motion_input.size(0), -1)  # [1 x batch x dim]

        # attention
        attn_weights = self.attn(last_hidden[-1], encoder_outputs)  # [batch x 1 x T]
        context = attn_weights.bmm(encoder_outputs.transpose(0, 1))  # [batch x 1 x attn_size]
        context = context.transpose(0, 1)  # [1 x batch x attn_size]

        # make input vec
        rnn_input = torch.cat((motion_input, context), 2)  # [1 x batch x (dim + attn_size)]

        if self.speaker_model:
            assert vid_indices is not None
            speaker_context = self.speaker_embedding(vid_indices).unsqueeze(0)
            rnn_input = torch.cat((rnn_input, speaker_context), 2)  # [1 x batch x (dim + attn_size + embed_size)]

        rnn_input = self.pre_linear(rnn_input.squeeze(0))
        rnn_input = rnn_input.unsqueeze(0)

        # rnn
        output, hidden = self.gru(rnn_input, last_hidden)

        # post-fc
        output = output.squeeze(0)  # [1 x batch x hidden_size] -> [batch x hidden_size]
        output = self.out(output)

        return output, hidden, attn_weights


class Generator(nn.Module):
    def __init__(self, args, motion_dim, discrete_representation=False, speaker_model=None):
        super(Generator, self).__init__()
        self.output_size = motion_dim
        self.n_layers = args.n_layers
        self.discrete_representation = discrete_representation
        self.decoder = BahdanauAttnDecoderRNN(input_size=motion_dim,
                                              hidden_size=args.hidden_size,
                                              output_size=self.output_size,
                                              n_layers=self.n_layers,
                                              dropout_p=args.dropout_prob,
                                              discrete_representation=discrete_representation,
                                              speaker_model=speaker_model)

    def freeze_attn(self):
        self.decoder.freeze_attn()

    def forward(self, z, motion_input, last_hidden, encoder_output, vid_indices=None):
        if z is None:
            input_with_noise_vec = motion_input
        else:
            assert not self.discrete_representation  # not valid for discrete representation
            input_with_noise_vec = torch.cat([motion_input, z], dim=1)  # [bs x (10+z_size)]

        return self.decoder(input_with_noise_vec, last_hidden, encoder_output, vid_indices)


class Seq2SeqNet(nn.Module):
    def __init__(self, args, pose_dim, n_frames, n_words, word_embed_size, word_embeddings, speaker_model=None):
        super().__init__()
        self.encoder = EncoderRNN(
            n_words, word_embed_size, args.hidden_size, args.n_layers,
            dropout=args.dropout_prob, pre_trained_embedding=word_embeddings)
        self.decoder = Generator(args, pose_dim, speaker_model=speaker_model)

        self.n_frames = n_frames
        self.n_pre_poses = args.n_pre_poses
        self.pose_dim = pose_dim

    def forward(self, in_text, in_lengths, poses, vid_indices):
        # reshape to (seq x batch x dim)
        in_text = in_text.transpose(0, 1)
        poses = poses.transpose(0, 1)

        outputs = torch.zeros(self.n_frames, poses.size(1), self.decoder.output_size).to(poses.device)

        # run words through encoder
        encoder_outputs, encoder_hidden = self.encoder(in_text, in_lengths, None)
        decoder_hidden = encoder_hidden[:self.decoder.n_layers]  # use last hidden state from encoder

        # run through decoder one time step at a time
        decoder_input = poses[0]  # initial pose from the dataset
        outputs[0] = decoder_input

        for t in range(1, self.n_frames):
            decoder_output, decoder_hidden, _ = self.decoder(None, decoder_input, decoder_hidden, encoder_outputs,
                                                             vid_indices)
            outputs[t] = decoder_output

            if t < self.n_pre_poses:
                decoder_input = poses[t]  # next input is current target
            else:
                decoder_input = decoder_output  # next input is current prediction

        return outputs.transpose(0, 1)


class Generator_gru(nn.Module):
    def __init__(self):
        super().__init__()
        self.WavEncoder = WavEncoder()
        self.hidden_size = 200
        self.output_size = 512

        self.project = nn.GRU(input_size=32, hidden_size=self.hidden_size, num_layers=2, dropout=0.1, bidirectional=True, batch_first=True)
        self.norm = nn.LayerNorm(self.hidden_size)
        self.out = nn.Linear(self.hidden_size, self.output_size)

    def sample(self, x):
        wav_feature = self.WavEncoder(x)
        hidden = None
        outputs, hidden = self.project(wav_feature, hidden)
        outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]  # Sum bidirectional outputs, ((batch, seq_len=240, )
        outputs = self.norm(outputs)
        codebook_embedding = self.out(outputs)
        code = torch.tensor([]).to(x.device)
        for k in codebook_embedding:
            probs = F.softmax(k, dim=-1)
            _, ix = torch.topk(probs, k=1, dim=-1)
            code = torch.cat((code, ix.squeeze(-1)))
        return [code.unsqueeze(0).long()]

    def forward(self, x, target=None):      # (b, len, 13)
        wav_feature = self.WavEncoder(x)        # (b, 30, 32)
        hidden = None

        outputs, hidden = self.project(wav_feature, hidden)       # (batch, seq_len=240, num_directions * hidden_size)
        outputs = outputs[:, :, :self.hidden_size] + outputs[:, :, self.hidden_size:]  # Sum bidirectional outputs, ((batch, seq_len=240, )

        outputs = self.norm(outputs)
        codebook_embedding = self.out(outputs)

        loss = None
        if target is not None:
            loss = F.cross_entropy(codebook_embedding.view(-1, codebook_embedding.size(-1)), target.view(-1))
        return codebook_embedding, loss


class Generator_diff(nn.Module):
    def __init__(self):
        super().__init__()
        self.WavEncoder = WavEncoder()
        seq_len = 240
        joints = 15
        n_dim = 9
        n_channels = joints * n_dim
        audio_dim = 32

        model = myUnet1D(
            dim=64,
            dim_mults=(1, 2, 4, 8),
            channels=n_channels,
            self_condition=True,
            audio_dim=audio_dim
        )

        self.diffusion = myGaussianDiffusion1D(
            model,
            seq_length=seq_len,
            timesteps=250,
            objective='pred_v',
            audio_dim=audio_dim,
            loss_type='huber'
        )

    def sample(self, batch_size, tmp_audio):
        wav_feature = self.WavEncoder(tmp_audio).transpose(1, 2)  # (b, 240, 32)
        sampled_seq = self.diffusion.sample(batch_size=batch_size, tmp_audio_feat=wav_feature)
        return sampled_seq

    def forward(self, target, x):      # (b, len, 13)
        wav_feature = self.WavEncoder(x).transpose(1, 2)        # (b, 240, 32)
        loss = self.diffusion(target, wav_feature)
        return loss


if __name__ == '__main__':
    '''
    cd mydiffusion/generate/
    python generate.py
    '''
    audio = torch.rand(2, 64000)
    pose = torch.rand(2, 240, 135).transpose(1, 2)

    # z = torch.arange(0, 60).reshape(2, 30)
    # model = Generator_gru()
    model = Generator_diff()
    loss = model(pose, audio)        # (b, 30, 32)
    pdb.set_trace()
    sampled_seq = model.sample(batch_size=1)
    print(sampled_seq.shape)      # (4, 32, 128)




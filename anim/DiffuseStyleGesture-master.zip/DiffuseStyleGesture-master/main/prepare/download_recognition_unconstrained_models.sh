mkdir -p assets/actionrecognition/
cd assets/actionrecognition/

echo -e "Downloading the HumanAct12 action recognition model, adjusted for the unconstrained setting."
gdown "1xfigimkPxKt3a8zvn_ME_NAR6CyTqneK"
echo -e

echo -e "Downloading done!"

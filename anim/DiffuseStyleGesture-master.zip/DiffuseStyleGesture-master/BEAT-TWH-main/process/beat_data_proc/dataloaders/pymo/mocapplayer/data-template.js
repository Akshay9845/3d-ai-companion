var dataBuffer = `$$DATA$$`;

start(dataBuffer);
.. _acknowledgement:

Acknowledgement
===============

The development of openSMILE and openEAR has received funding from the
European Community’s Seventh Framework Programme (FP7/2007-2013) under
grant agreement No.211486 (SEMAINE).

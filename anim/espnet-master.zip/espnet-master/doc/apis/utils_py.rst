.. _python utility tools:

python utility tools
====================

ESPnet provides several command-line python tools under ``utils/``

.. include:: ../_gen/utils_py.rst

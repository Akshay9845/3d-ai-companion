.. _bash utility tools:

bash utility tools
==================

ESPnet provides several command-line bash tools under ``utils/``

.. include:: ../_gen/utils_sh.rst

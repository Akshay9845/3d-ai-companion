.. _core tools (espnet2):

core tools (espnet2)
====================

ESPnet2 provides several command-line tools for training and evaluating neural networks (NN) under ``espnet2/bin``:

.. include:: ../_gen/espnet2_bin.rst
